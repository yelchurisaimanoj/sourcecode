const apiUrl = 'https://api.magunta.in/api';

//const apiUrl = 'http://localhost:53174/api';
// const apiUrl = 'http://216.10.247.207:8082/api';

export default apiUrl;
