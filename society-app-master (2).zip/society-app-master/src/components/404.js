import React from 'react';

const PageNotFoundError = () => {
  return (
    <div>
      <h2>404 - Page Not Found Error</h2>
    </div>
  );
};

export default PageNotFoundError;